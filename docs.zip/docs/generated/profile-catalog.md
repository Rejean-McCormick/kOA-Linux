# Profile Catalog

| ID | Path | Status | Version |
| --- | --- | --- | --- |
| appliance_shell | contracts/profiles/appliance-shell.profile.json | active | 1.0.0 |
| build_farm | contracts/profiles/build-farm.profile.json | active | 1.0.0 |
| control_plane | contracts/profiles/control-plane.profile.json | active | 1.0.0 |
| developer_linux_workstation | contracts/profiles/developer-linux-workstation.profile.json | active | 1.0.0 |
| developer_windows_wsl | contracts/profiles/developer-windows-wsl.profile.json | active | 1.0.0 |
| high_assurance | contracts/profiles/high-assurance.profile.json | active | 1.0.0 |
| sovereign_hub | contracts/profiles/sovereign-hub.profile.json | active | 1.0.0 |
| sovereign_linux_node | contracts/profiles/sovereign-linux-node.profile.json | active | 1.0.0 |
| sovereign_offline | contracts/profiles/sovereign-offline.profile.json | active | 1.0.0 |
| user_lightweight | contracts/profiles/user-lightweight.profile.json | active | 1.0.0 |
