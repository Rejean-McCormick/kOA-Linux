# Subsystem Catalog

| ID | Path | Status | Version |
| --- | --- | --- | --- |
| ariane | contracts/subsystems/ariane.subsystem.json | active | 1.0.0 |
| konnaxion | contracts/subsystems/konnaxion.subsystem.json | active | 1.0.0 |
| orgo | contracts/subsystems/orgo.subsystem.json | active | 1.0.0 |
| semantik_architect | contracts/subsystems/semantik-architect.subsystem.json | active | 1.0.0 |
| sentient | contracts/subsystems/sentient.subsystem.json | active | 1.0.0 |
| uckk | contracts/subsystems/uckk.subsystem.json | active | 1.0.0 |
