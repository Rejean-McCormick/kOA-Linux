# Component Catalog

| ID | Path | Status | Version |
| --- | --- | --- | --- |
| audit_broker | contracts/components/audit-broker.component.json | active | 1.0.0 |
| governance_policy_runtime | contracts/components/governance-policy-runtime.component.json | active | 1.0.0 |
| identity_and_trust | contracts/components/identity-and-trust.component.json | active | 1.0.0 |
| koa_node_agent | contracts/components/koa-node-agent.component.json | active | 1.0.0 |
| kristal_runtime | contracts/components/kristal-runtime.component.json | active | 1.0.0 |
| publication_gateway | contracts/components/publication-gateway.component.json | active | 1.0.0 |
| resource_governor | contracts/components/resource-governor.component.json | active | 1.0.0 |
| uckk_dimension_gateway | contracts/components/uckk-dimension-gateway.component.json | active | 1.0.0 |
